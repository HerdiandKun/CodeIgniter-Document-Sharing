	
<div class="well well-md">
	<div class="container">
		<p>&nbsp;</p>		
		<address>
			<p>
				<strong>
						<i class="glyphicon glyphicon-map-marker"></i> Alamat
				</strong>
			
			</p>
			<p>
				<strong>
						<i class="glyphicon glyphicon-phone-alt"></i> Telepon
				</strong>
				534534 &copy; 2014
			</p>
		</address>
	</div>
</div>


    </body>
</html>

<!-- JS -->
<script src="<?PHP echo base_url();?>assets/java/jquery-2.1.1.min.js"></script>
<script src="<?PHP echo site_url();?>assets/java/bootstrap.min.js"></script>
<script src="<?PHP echo base_url();?>assets/java/jquery.dataTables.min.js"></script>
<script type="text/javascript">
$(document).ready(function(e) {
	
	
	$('.table').dataTable();
	
});

</script>